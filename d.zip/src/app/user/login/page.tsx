"use client";
import CustomLoginForm from "@/shared/components/CustomLoginPage";
import { Container, Box, Stack, Button } from "@mui/material";
import { signIn } from "next-auth/react";

const LoginPage = () => {
  const login = async (data: any) => {

    await signIn("credentials", {
      username: data.email,
      password: data.password,
      redirect: true,
      callbackUrl: "http://localhost:3000/task/home",
    });
  };
  return (
    <Container maxWidth={"lg"}>
      <Box height={"100vh"} width={"100vw"}>
        <Stack
          height={"100%"}
          width={"sm"}
          flexDirection={"column"}
          justifyContent={"center"}
          alignItems={"center"}
          marginRight={"5vw"}
        >
          <Button onClick={()=>signIn('github',{redirect:true,callbackUrl:'http://localhost:3000/task/home'})}>Login with Github</Button>
          <CustomLoginForm login={login} />
        </Stack>
      </Box>
    </Container>
  );
};

export default LoginPage;
