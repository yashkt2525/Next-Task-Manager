const page = () => {
  return (
    <div>User Page</div>
  )
}

export default page