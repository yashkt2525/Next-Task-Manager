"use client"
import Image from 'next/image'
import styles from './page.module.css'
import { Box, Button, Stack, createTheme } from '@mui/material'
import { useRouter } from 'next/router'
import Link from 'next/link'
import { ThemeProvider } from '@emotion/react'
import { lightGreen, red } from '@mui/material/colors'
import { useSession } from 'next-auth/react'
import { redirect } from 'next/navigation'

   function Home() {
  return (
   
     <Box height={'100vh'} width={'100vw'}>
   
    
    <Stack height={'100%'} width={'100%'} spacing={{ xs: 1, sm: 2 }} direction="row" useFlexGap flexWrap="wrap" justifyContent={'center'} alignItems={'center'}>
    
     <Link href={'/user/login'}> <Button variant='outlined'>Login</Button></Link>
  </Stack>
  </Box>
 
  )
}
export default Home;

