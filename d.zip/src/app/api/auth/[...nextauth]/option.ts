import type { NextAuthOptions } from "next-auth";
import GitHubProvider from "next-auth/providers/github";
import CredentialsProvider from "next-auth/providers/credentials";
interface obj {
  id: string;
  email: string;
  name: string;
}
export const options: NextAuthOptions = {
  providers: [
    GitHubProvider({
      clientId: process.env.GITHUB_ID as string,
      clientSecret: process.env.GITHUB_SECRET as string,
    }),
    CredentialsProvider({
      name: "credentials",
      credentials: {
        username: {
          label: "Username:",
          type: " text",
          placeholder: "Your username",
        },
        password: {
          label: "Password",
          type: "password",
          placeholder: "Enter your Password Here",
        },
      },
      async authorize(credentials) {
        const userArr: Array<obj> = [
          { id: "1", email: "yash@gmail.com", name: "Yash" },
          { id: "2", email: "koibhi@gmail.com", name: "Papa" },
          { id: "3", email: "xyz@gmail.com", name: "xyz" },
        ];

        const user: obj | undefined = userArr.find(
          (ele: { email: string }) => ele.email === credentials?.username
        );
        if (user) {
          return user;
        } else {
          return null;
        }
      },
    }),
  ],

  callbacks: {
    async jwt({ token }) {
      return token;
    },
    async session({ session }) {
      return session;
    },
  },
  pages: {
    signIn: "/user/login",
  },
};
