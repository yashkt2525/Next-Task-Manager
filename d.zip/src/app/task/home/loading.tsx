import {Box} from '@mui/material';

const loading = () => {
  return (
    <Box height={'85vh'} width={'100vw'}>
    <div>loading...</div>
    </Box>
  )
}

export default loading;